/*:
 # Clean Up!
 
 ## How to play?
 
 - Click on "Run My Code" to start your mission!
 
 * Callout(Note):
 Ensure "Enable Results" is set to OFF to prevent any lag.

 - Click on the screen to the extend the grabber. The grabber will pick up any object it finds hence it is your duty to pick up only plastic wastes.
 - Picking up plastic wastes will award you **10 points**.
 - But picking up fishes will award you **-10 points**.
 - The score is initially set to 100
 - You have 120 seconds to clean the ocean. Good luck!
 
 * Callout(Note):
 Please use full screen for the best experience
 
 */

/*:
 Made by Parasa V. Prajwal.
 */

//#-hidden-code
import SpriteKit
import UIKit
import PlaygroundSupport

let skView = SKView(frame: .zero)

let gameScene = GameScene(size: UIScreen.main.bounds.size)
gameScene.scaleMode = .aspectFill
skView.presentScene(gameScene)

PlaygroundPage.current.liveView = skView
PlaygroundPage.current.wantsFullScreenLiveView = true

//#-end-hidden-code
