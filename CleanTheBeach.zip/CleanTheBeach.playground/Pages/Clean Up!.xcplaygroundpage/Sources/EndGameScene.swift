
import SpriteKit
import SwiftUI


public class EndGameScene: SKScene {
    public override func didMove(to view: SKView) {
        //bg
        backgroundColor = SKColor.black
        //label
        let scoreLabel = SKLabelNode(fontNamed:"Helevetica-Bold")
        scoreLabel.color = .white
        scoreLabel.text = "Good job! Your score is " + String(scoreValue) + "!"
        scoreLabel.fontSize = 60
        scoreLabel.position = CGPoint(x: frame.midX, y: frame.midY)
        scoreLabel.zPosition = 10
        addChild(scoreLabel)
    } 
}
