

import SpriteKit
import SwiftUI
import PlaygroundSupport

struct PhysicsCategory {
    static let none : UInt32 = 0
    static let all  : UInt32 = UInt32.max
    static let hook : UInt32 = 0b1
    static let fish : UInt32 = 0b10
    static let waste: UInt32 = 0b11
}

var scoreValue = 100
let scoreLabel = SKLabelNode(fontNamed:"Helevetica-Bold")

public class GameScene: SKScene {
    var nodeToDie: SKSpriteNode?
    let hook = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "hook2.png")))
    var verdict : SKSpriteNode?
    let timerNode = SKLabelNode(fontNamed:"Helevetica-Bold")
    var time : Int = 120
    {
        didSet{
            if(time >= 10){
                timerNode.text = "\(time)"
            }
            else{
                timerNode.text = "0\(time)"
            }
        }
    }
    
    private func countdown(){
        time -= 1
        if(time <= 0){
            endGame()
        }
    }
    public override func didMove(to view: SKView) {
        //bg
        let background = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "beachback.png")))
        background.position = CGPoint(x: frame.midX, y: frame.midY)
        background.zPosition = 0
        addChild(background)
        //label
        scoreLabel.text = "Score: " + String(scoreValue)
        scoreLabel.fontSize = 60
        scoreLabel.position = CGPoint(x: size.width * 0.15, y: size.height * 0.90)
        scoreLabel.zPosition = 10
        addChild(scoreLabel)
        timerNode.fontSize = 60
        timerNode.position = CGPoint(x: size.width * 0.85, y: size.height * 0.90)
        timerNode.zPosition = 10
        addChild(timerNode)
        //hook
        hook.position = CGPoint(x: size.width / 2, y: size.height * 0.95)
        hook.anchorPoint = CGPoint(x: 0.5, y: 1.0)
        hook.zPosition = 5
        hook.setScale(0.75)
        addChild(hook)
        physicsWorld.gravity = .zero
        physicsWorld.contactDelegate = self
        swingHook()
        run(SKAction.repeatForever(SKAction.sequence([SKAction.run(countdown) , SKAction.wait(forDuration: 1)])))
        run(SKAction.repeatForever(
            SKAction.sequence([
                SKAction.run(addFish),
                SKAction.wait(forDuration: 2.0),
                SKAction.run(addWaste),
                SKAction.wait(forDuration: 2.0)
            ])
        ))
    }
    func random() -> CGFloat {
        return CGFloat(Float(arc4random()) / 0xFFFFFFFF)
    }
    
    func random(min: CGFloat, max: CGFloat) -> CGFloat {
        return random() * (max - min) + min
    }
    
    func swingHook() {
        hook.texture = SKTexture(image: #imageLiteral(resourceName: "hook2.png"))
        scoreLabel.text =  "Score: " + String(scoreValue)
        hook.physicsBody = SKPhysicsBody(circleOfRadius : CGFloat(30),
                                         center: CGPoint(x: hook.anchorPoint.x, y: ((hook.anchorPoint.y - hook.size.height) * 0.75)))
        hook.physicsBody?.isDynamic = true
        hook.physicsBody?.categoryBitMask = PhysicsCategory.hook
        hook.physicsBody?.contactTestBitMask = PhysicsCategory.fish
        hook.physicsBody?.collisionBitMask = PhysicsCategory.none
        hook.physicsBody?.usesPreciseCollisionDetection = true
        nodeToDie?.removeFromParent()
        verdict?.removeFromParent()
        hook.zRotation = 0
        let angle = hook.zRotation
        let firstTime = (.pi/3 - angle) * (3 / .pi)
        let  first = SKAction.rotate(byAngle: (.pi/3 - angle), duration: TimeInterval(firstTime));
        let  second = SKAction.rotate(byAngle: -2 * .pi/3, duration: 2);
        let  third = SKAction.rotate(byAngle: .pi/3, duration: 1);
        hook.run(SKAction.repeatForever(
            SKAction.sequence([first, second, third])
        ),withKey: "hookAction")
        
    }
    
    func Dist(first : CGPoint, second : CGPoint) -> CGFloat {
        return CGFloat(hypotf(Float(second.x - first.x), Float(CGFloat(second.y - first.y))));
    }
    
    func goForward() {
        let angle = hook.zRotation
        let ax = hook.position.x
        let ay = hook.position.y
        let units = CGFloat(600.0)
        let fx = ax + (units * CGFloat(sinf(Float(angle))))
        let fy = ay - (units * CGFloat(cosf(Float(angle))))
        let goMove = SKAction.move(to: CGPoint(x: fx , y: fy),
                                   duration: TimeInterval(0.75))
        hook.run(goMove)
    }
    
    func comeBack() {
        let units: CGFloat
        units = Dist(first: CGPoint(x: size.width / 2, y: size.height * 0.95), second: hook.position)
        let time = Float((units*3)/1400)
        let goBack = SKAction.move(to : CGPoint(x: size.width / 2, y: size.height * 0.95),
                                   duration: TimeInterval(time))
        hook.run(goBack, completion: swingHook)
    }
    func comeBackNode(node : SKSpriteNode) {
        let units: CGFloat
        units = Dist(first: CGPoint(x: size.width / 2, y: size.height * 0.95), second: node.position)
        let time = Float((units*3)/1400)
        let goBack = SKAction.move(to : CGPoint(x: size.width / 2, y: size.height * 0.95),
                                   duration: TimeInterval(time))
        node.run(goBack)
    }
    
    func bringNode(hook: SKSpriteNode, node: SKSpriteNode) {
        nodeToDie = node
        hook.texture = SKTexture(image: #imageLiteral(resourceName: "hook.png"))
        comeBackNode(node: node)
        comeBack()
    }
    
    func addWaste() {
        var waste : SKSpriteNode
        let x = random(min: 1, max: 4)
        if(x < 2){
            waste = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "cup.png")))
        }
        else if(x < 3){
            waste = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "bottle.png")))
        }
        else{
            waste = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "bag.png")))
        }
        waste.physicsBody = SKPhysicsBody(circleOfRadius: waste.size.height/2)
        waste.physicsBody?.isDynamic = true
        waste.physicsBody?.categoryBitMask = PhysicsCategory.waste
        waste.physicsBody?.contactTestBitMask = PhysicsCategory.hook
        waste.physicsBody?.collisionBitMask = PhysicsCategory.none
        waste.physicsBody?.usesPreciseCollisionDetection = true
        let actualY = random(min: waste.size.height/2, max: (  size.height * 0.75 ) - waste.size.height/2)
        waste.position = CGPoint(x: waste.size.width/2, y: actualY)
        waste.zPosition = 2
        addChild(waste)
        let actualDuration = random(min: CGFloat(15.5), max: CGFloat(20.5))
        let actionMove = SKAction.move(to: CGPoint(x: size.width + waste.size.width/2, y: actualY),
                                       duration: TimeInterval(actualDuration))
        let actionMoveDone = SKAction.removeFromParent()
        waste.run(SKAction.sequence([actionMove, actionMoveDone]))
    }
    
    func addFish() {
        var fish : SKSpriteNode
        let x = random(min: 1, max: 3)
        if(x < 2){
            fish = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "fish1.png")))
        }
        else{
            fish = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "fish2.png")))
        }
        fish.physicsBody = SKPhysicsBody(circleOfRadius: fish.size.height/2)
        fish.physicsBody?.isDynamic = true
        fish.physicsBody?.categoryBitMask = PhysicsCategory.fish
        fish.physicsBody?.contactTestBitMask = PhysicsCategory.hook
        fish.physicsBody?.collisionBitMask = PhysicsCategory.none
        fish.physicsBody?.usesPreciseCollisionDetection = true
        let actualY = random(min: fish.size.height/2, max: (  size.height * 0.75 ) - fish.size.height/2)
        fish.position = CGPoint(x: fish.size.width/2, y: actualY)
        fish.zPosition = 3
        addChild(fish)
        let actualDuration = random(min: CGFloat(15.5), max: CGFloat(20.5))
        let actionMove = SKAction.move(to: CGPoint(x: size.width + fish.size.width/2, y: actualY),
                                       duration: TimeInterval(actualDuration))
        let actionMoveDone = SKAction.removeFromParent()
        fish.run(SKAction.sequence([actionMove, actionMoveDone]))
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard touches.first != nil else {
            return
        }
        hook.removeAction(forKey: "hookAction")
        if(hook.hasActions()==false){
            hook.run(SKAction.sequence([
                SKAction.run(goForward),
                SKAction.wait(forDuration: 1),
                SKAction.run(comeBack),
                SKAction.wait(forDuration: 0.75)
            ]),withKey: "movingAction")
        }
        
    }
    
    func nodeDidCollideWithHook(hook: SKSpriteNode, node: SKSpriteNode) {
        if let _ = hook.action(forKey: "movingAction") {
            if((node.physicsBody!.categoryBitMask) == PhysicsCategory.fish){
                scoreValue -= 10
                verdict = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "minus10.png")))
            }
            else{
                scoreValue += 10
                verdict = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "plus10.png")))
            }
            verdict?.position = CGPoint(x: scoreLabel.position.x, y: scoreLabel.position.y * 0.9)
            verdict?.zPosition = 13
            verdict?.setScale(0.05)
            hook.removeAllActions()
            addChild(verdict!)
            hook.physicsBody?.collisionBitMask = 0
            hook.physicsBody?.contactTestBitMask = 0
            bringNode(hook: hook, node: node)
        } else {
            // already hit
        }
    }
    func endGame(){
        let endScene = EndGameScene(size: UIScreen.main.bounds.size)
        endScene.scaleMode = .aspectFill
        self.view?.presentScene(endScene, transition: SKTransition.fade(with: .black, duration: 0.5))
    }
}

extension GameScene: SKPhysicsContactDelegate {
    public func didBegin(_ contact: SKPhysicsContact) {
        var firstBody: SKPhysicsBody
        var secondBody: SKPhysicsBody
        if contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask {
            firstBody = contact.bodyA
            secondBody = contact.bodyB
        } else {
            firstBody = contact.bodyB
            secondBody = contact.bodyA
        }
        if ((firstBody.categoryBitMask == PhysicsCategory.hook ) &&
                (secondBody.categoryBitMask ==   PhysicsCategory.fish )) {
            if let hook = firstBody.node as? SKSpriteNode,
               let fish = secondBody.node as? SKSpriteNode {
                nodeDidCollideWithHook(hook: hook, node: fish)
            }
        }
        else if ((firstBody.categoryBitMask == PhysicsCategory.hook) &&
                    (secondBody.categoryBitMask == PhysicsCategory.waste)) {
            if let hook = firstBody.node as? SKSpriteNode,
               let waste = secondBody.node as? SKSpriteNode {
                nodeDidCollideWithHook(hook: hook, node: waste)
            }
        }
    }
}
