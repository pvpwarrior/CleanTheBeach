/*:
 # Introduction
 
 The scientists of Evil Inc. were disgusted when they saw their local beach 🏝 filled with plastic trash. These bags, cups and bottles not only pollute the natural scenery but are also destroying the marine life under the sea! 🌊
 
 
 So they decided to turn good and invented a device that actually helped society. They call it - **'the Plastic recycle-inator 3000'**.
 Using a revolutionary technology, this device takes in plastic waste 🥤 and magically converts it into delicious ice-cream (that is perfectly edible) 🍦!
 
 
 But there’s a catch - If you accidentally feed the machine some aquatic animals, its efficiency decreases (as it has a hard time converting fish into ice-cream). This makes it harder for our (ex-)evil scientists 👨‍🔬 to maintain the device and keep the seas clean!
 
 * Callout(Note):
 If the device takes in anything 
 **other than plastic waste**, its efficiency **decreases.**

 */

/*:
 # What can you do?
 
 The scientists haven chosen YOU to collect plastic waste from the ocean water. Remember that the responsibility of keeping the ocean clean lies in your hands!
 */

//: [Next](@next)

/*: 
 Made by Parasa V. Prajwal.
 */

//#-hidden-code

import SpriteKit
import PlaygroundSupport
import CoreGraphics

let skView = SKView(frame: CGRect(x: 0, y: 0, width: 350, height: 500))

PlaygroundPage.current.liveView = skView

let introScene = IntroScene(size: CGSize(width: 350, height: 500))
introScene.scaleMode = .aspectFill
skView.presentScene(introScene)

//#-end-hidden-code
