import SpriteKit
import SwiftUI

public class IntroScene: SKScene {
    public override func didMove(to view: SKView) {
        let background = SKSpriteNode(texture: SKTexture(image: #imageLiteral(resourceName: "newsbg.png")))
        background.position = CGPoint(x: frame.midX, y: frame.midY)
        background.zPosition = 0
        let a = frame.size.width / background.size.width
        let b = frame.size.height / background.size.height
        let ab = min(a, b)
        background.setScale(ab)
        addChild(background)
    }
}
